## run these commands in the terminal at the base directory of the project
# installing libraries
    '''
        pip install -r requirements.txt
    '''

# migrate database
    '''
        python manage.py migrate
    '''

# start server
    '''
        python manage.py runserver
    '''